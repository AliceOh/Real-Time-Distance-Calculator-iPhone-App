//
//  AppDelegate.h
//  DistanceCalculator
//
//  Created by wikigainoh on 22/11/17.
//  Copyright © 2017 HelloWorldCop. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

